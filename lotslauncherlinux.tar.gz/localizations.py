import os
import json
import locale

class Localization:
    _translations = {}
    _default_language = "en"

    @staticmethod
    def load_language(language_code=None):
        """
        Carrega as traduções do arquivo translations.json.
        Se não encontrar o idioma especificado, usa o fallback 'en'.
        """
        # Caminho para o arquivo JSON
        file_path = os.path.join(os.path.dirname(__file__), "Resources", "translations.json")

        if not os.path.exists(file_path):
            raise FileNotFoundError("Arquivo translations.json não encontrado.")

        # Carrega o JSON
        with open(file_path, "r", encoding="utf-8-sig") as file:
            all_translations = json.load(file)

        # Obtém o idioma base (ex: "pt" de "pt-BR")
        if language_code is None:
            # Detecta o idioma do sistema
            language_code, _ = locale.getdefaultlocale()

        base_language = language_code.split("-")[0]
        base_language = base_language.split("_")[0]
        print(base_language)
        # Tenta carregar as traduções para o idioma ou usa o fallback
        if base_language in all_translations:
            Localization._translations = all_translations[base_language]
        elif Localization._default_language in all_translations:
            Localization._translations = all_translations[Localization._default_language]
        else:
            Localization._translations = {}
            print("Nenhuma tradução encontrada, nem mesmo o fallback.")

    @staticmethod
    def get_string(key):
        """
        Retorna a string traduzida para a chave fornecida.
        Se não encontrar, retorna a própria chave.
        """
        print(Localization._translations.get(key, key))
        return Localization._translations.get(key, key)
