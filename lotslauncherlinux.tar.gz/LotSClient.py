#!/usr/bin/env python3
# Created by: Leandro Balico
# Date: 2024-06-17
# License: MIT (https://opensource.org/licenses/MIT)
import gi
import os
import threading
import subprocess
from git import Repo, GitCommandError, InvalidGitRepositoryError
from localizations import Localization
import time
# Import GTK and Gdk for GUI
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Pango

"""
LotSClient is a GTK-based launcher for the game.
It checks and updates the repository, displays progress, and launches the game.
"""
class LotSClient(Gtk.Window):
    # Paths and constants
    GAME_PATH = os.path.join(os.getcwd(), "Game")
    REPO_URL = "https://github.com/leanball/LotSGameLinux.git"  # Replace with the actual repository URL
    BG_IMAGE_PATH = "Resources/background.png"
    FONT_PATH = "Resources/CinzelDecorative.ttf"
    GAME_EXECUTABLE = os.path.join(GAME_PATH, "LotSLinux", "LotS.x86_64")
    FADE_DURATION = 2000
    """
    Initialize the launcher window and UI components.
    """
    def __init__(self):

        super().__init__(title="LotS Launcher")
        self.set_default_size(545, 500)
        self.set_resizable(False)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_decorated(False)
        #self.set_opacity(0)

        # Load system language
        Localization.load_language()

        # Apply CSS styling for background and font
        self.apply_css()
        
        

        # Check for transparency support
        self.screen = self.get_screen()
        if self.screen.is_composited():
            self.set_app_paintable(False)
            self.set_visual(self.screen.get_rgba_visual())
            self.set_opacity(0)

        # Build the UI
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.main_box.set_valign(Gtk.Align.END)
        self.main_box.set_halign(Gtk.Align.CENTER)

        # Status label
        self.lbl_status = Gtk.Label(label=Localization.get_string("Initializing"))
        self.lbl_status.get_style_context().add_class("custom-label")


        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_fraction(0.0)

        # Progress label
        self.lbl_progress = Gtk.Label(label="0%")
        self.lbl_progress.get_style_context().add_class("custom-label")


        # Add widgets to the layout
        self.main_box.pack_start(self.lbl_status, False, False, 5)
        self.main_box.pack_start(self.progress_bar, False, False, 5)
        self.main_box.pack_start(self.lbl_progress, False, False, 5)
        self.set_progress_ui(False)
        # Add layout to the window
        self.add(self.main_box)
        
        # Start the Git update process in the background
        threading.Thread(target=self.initialize_launcher).start()
    

    """
    Apply CSS to set the background image and custom font for labels.
    """
    def apply_css(self):
        """
        Apply CSS to set the background image.
        """
        css = f"""
        window {{
            background-image: url("{self.BG_IMAGE_PATH}");
            background-size: cover;
        }}
        .custom-label {{
            font-family: 'Cinzel Decorative', serif;
            font-size: 16px;
            color: white;
        }}
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css.encode("utf-8"))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_USER
        )
    
    def fade_in(self):
        """
        Gradually increase window opacity to 1.0 over the specified duration.
        """
        steps = 100
        step_opacity = 1.0 / steps
        step_delay = self.FADE_DURATION / steps / 1000  # Delay per step in seconds
        current_opacity = 0.0
        for i in range(steps):
            current_opacity += step_opacity
            self.set_opacity(current_opacity)
            time.sleep(step_delay)  
        self.set_opacity(1.0) 

    def fade_out(self):
        """
        Gradually decrease window opacity to 0.0 over the specified duration.
        """
        steps = 100
        step_opacity = 1.0 / steps
        step_delay = self.FADE_DURATION / steps / 1000  # Delay per step in seconds
        current_opacity = 1.0
        for i in range(steps):
            current_opacity -= step_opacity
            self.set_opacity(current_opacity)
            time.sleep(step_delay)  
        self.set_opacity(0.0)  

    """
    Show or Hide the progress bar and progress label.
    """
    def set_progress_ui(self, visible):

        GLib.idle_add(self.progress_bar.set_visible, visible)
        GLib.idle_add(self.lbl_progress.set_visible, visible)
    
    """
    Main launcher logic: checks and updates the game repository.
    """
    def initialize_launcher(self):
        if self.screen.is_composited():
            self.fade_in()
        try:
            # Step 1: Check if the repository is valid or clone it
            if not os.path.exists(os.path.join(self.GAME_PATH, ".git")):
                self.set_progress_ui(True)
                self.update_status(Localization.get_string("GameNotFound"), 0)
                Repo.clone_from(self.REPO_URL, self.GAME_PATH, progress=self.git_progress)
                self.update_status(Localization.get_string("GameUpToDate"),1.0)
                self.set_progress_ui(False)
                time.sleep(2)
                
            else:
                self.update_status(Localization.get_string("CheckingUpdates"),0)
                self.pull_updates()

            # Step 2: Launch the game
            self.update_status(Localization.get_string("LaunchingGame"), 1.0)
            self.launch_game()

        except (GitCommandError, InvalidGitRepositoryError, Exception) as e:
            # Show error pop-up instead of updating layout
            self.show_error_dialog(Localization.get_string("Error"), str(e))
            self.update_status(f"{Localization.get_string('Error')}", 0.0)
    
    """
    Pull updates from the Git repository.
    """
    def pull_updates(self):
        """
        Pull updates from the Git repository and show progress.
        """
        repo = Repo(self.GAME_PATH)
        self.set_progress_ui(True)  # Show progress bar and label
        
        repo.remotes.origin.fetch(progress=self.git_progress)

        # Check if there are new commits
        commits_ahead = list(repo.iter_commits('HEAD..origin/HEAD'))
        if commits_ahead:
            self.update_status(Localization.get_string("ApplyingUpdates"), 0.5)
            # Pull updates
            repo.remotes.origin.pull(progress=self.git_progress)
            time.sleep(1)
            self.update_status(Localization.get_string("UpdatesApplied"), 1.0)
        else:
            self.update_status(Localization.get_string("GameUpToDate"), 1.0)
            time.sleep(1)

        self.set_progress_ui(False)  # Hide progress bar and label

    def git_progress(self, op_code, cur_count, max_count, message):
        """
        Git operation progress callback to update the progress bar and status.
        """
        if max_count > 0:
            fraction = cur_count / max_count
            GLib.idle_add(self.update_progress, fraction, message)

    def update_progress(self, fraction, message=""):
        """
        Update progress bar visually and optionally update the status message.
        """
        GLib.idle_add(self.progress_bar.set_fraction, fraction)
        if message:
            GLib.idle_add(self.lbl_status.set_text, message)
        GLib.idle_add(self.lbl_progress.set_text, f"{int(fraction * 100)}%")
    
    """
    Launch the game executable.
    """
    def launch_game(self):
        
        if os.path.exists(self.GAME_EXECUTABLE):
            if self.screen.is_composited():
                self.fade_out()
            os.system(f"chmod +x '{self.GAME_EXECUTABLE}' && '{self.GAME_EXECUTABLE}' --force-vulkan &")
            Gtk.main_quit()
        else:
            self.update_status(Localization.get_string("GameNotFoundError"), 0.0)
    
    """
    Update the status label and progress bar.
    """
    def update_status(self, text, progress):
        GLib.idle_add(self.lbl_status.set_text, text)
        GLib.idle_add(self.progress_bar.set_fraction, progress)
        GLib.idle_add(self.lbl_progress.set_text, f"{int(progress * 100)}%")
    
    """
    Progress callback for Git operations.
    """
    def git_progress(self, op_code, cur_count, max_count, message):

        if max_count > 0:
            fraction = cur_count / max_count
            self.update_progress(fraction)
    """
    Update progress bar visually.
    """
    def update_progress(self, fraction):
        GLib.idle_add(self.progress_bar.set_fraction, fraction)
        GLib.idle_add(self.lbl_progress.set_text, f"{int(fraction * 100)}%")
    
    """
    Display an error dialog with a title and message.
    """
    def show_error_dialog(self, title, message):
        dialog = Gtk.MessageDialog(
            parent=self,
            flags=Gtk.DialogFlags.MODAL,
            type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            message_format=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

def main():
    """
    Entry point for the GTK launcher application.
    """
    win = LotSClient()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()